#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: pca.R
#     Description: Principal Component Analysis
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Remove non numeric columns
iris_numeric = IRIS_TABLE[, c("Sepal.Length", "Sepal.Width",
                              "Petal.Length", "Petal.Width")]

# princomp
princomp(iris_numeric)

princomp(~ Sepal.Length + Sepal.Width + Petal.Length, data = iris_numeric,
         cor = TRUE)

princomp(~ Sepal.Length + Sepal.Width + Petal.Length, data = iris_numeric,
         subset = Sepal.Length < 5, cor = TRUE)

# prcomp
prcomp(iris_numeric)

prcomp(~ Sepal.Length + Sepal.Width + Petal.Length, data = iris_numeric,
       scale. = TRUE)

prcomp(~ Sepal.Length + Sepal.Width + Petal.Length, data = iris_numeric,
       subset = Sepal.Length > 5, scale. = TRUE)
