#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: push_pull.R
#     Description: Demonstrates collaborative processing between
#                  database and client R desktop

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Performing pre-processing, derivation of new columnsi,
# binning, aggregations, ranking etc  in the database
#
# For the example, we'll simply filter just one species
IRIS_TABLE = IRIS_TABLE[IRIS_TABLE$Species == "setosa", ]

# Pull filtered rows to desktop R client memory
inmem_df = ore.pull(IRIS_TABLE)
class(inmem_df)

# Apply R's own lm on inmem_df
# Alternatively you may imagine using any CRAN package whose functionality
# is not supported by the database on inmem_df
r_model = lm(Petal.Length ~ Petal.Width, inmem_df)
r_model

df = data.frame(residuals = residuals(r_model))

# Push df back to database
RESIDUALS <- ore.push(df)

