#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_esa.R
#     Description: ORE Interface to Oracle Data Mining Explicit Semantic
#                  Analysis
#

title <- c('Aids in Africa: Planning for a long war',
           'Mars rover maneuvers for rim shot',
           'Mars express confirms presence of water at Mars south pole',
           'NASA Announces major Mars rover finding',
           'Drug access, Asia threat in focus at AIDS summit',
           'NASA Mars Odyssey THEMIS image: typical crater',
           'Road blocks for Aids')
  # TEXT contents in character column
  df <- data.frame(CUST_ID = seq(length(title)), TITLE = title)
  ESA_TEXT <- ore.push(df)

  # TEXT contains in clob column
  attr(df$TITLE, "ora.type") <- "clob"
  ESA_TEXT_CLOB <- ore.push(df)

  # create text policy (CTXSYS.CTX_DDL privilege is required)
  ore.exec("Begin ctx_ddl.create_policy('ESA_TXTPOL'); End;")

  # specify TEXT POLICY_NAME, MIN_DOCUMENTS, MAX_FEATURES and
  # ESA algorithm settings in odm.settings
  esa.mod <- ore.odmESA(~., data = ESA_TEXT_CLOB,
    odm.settings = list(case_id_column_name = "CUST_ID",
                        ODMS_TEXT_POLICY_NAME = "ESA_TXTPOL",
                        ODMS_TEXT_MIN_DOCUMENTS = 1,
                        ODMS_TEXT_MAX_FEATURES = 3,
                        ESAS_MIN_ITEMS = 1,
                        ESAS_VALUE_THRESHOLD = 0.0001,
                        ESAS_TOPN_FEATURES = 3))
  class(esa.mod)
  summary(esa.mod)
  settings(esa.mod)
  features(esa.mod)
  predict(esa.mod, ESA_TEXT, type = "class", supplemental.cols = "CUST_ID")

  # use ctx.settings to specify character column as TEXT and
  # the same above settings as well as TOKEN_TYPE
  esa.mod2 <- ore.odmESA(~ TITLE, data = ESA_TEXT,
    odm.settings = list(case_id_column_name = "CUST_ID", ESAS_MIN_ITEMS = 1),
    ctx.settings = list(TITLE =
      "TEXT(POLICY_NAME:ESA_TXTPOL)(TOKEN_TYPE:STEM)(MIN_DOCUMENTS:1)(MAX_FEATURES:3)"))
  summary(esa.mod2)
  settings(esa.mod2)
  features(esa.mod2)
  predict(esa.mod2, ESA_TEXT_CLOB, type = "class", supplemental.cols = "CUST_ID")

  ore.exec("Begin ctx_ddl.drop_policy('ESA_TXTPOL'); End;")

