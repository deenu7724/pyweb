#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: ore_dplyr.R
#     Description: dplyr functionality upon ORE object
#

## load OREdplyr package
suppressMessages(library(OREdplyr))

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

##
## Data manipulation
##

# select data from sepcified columns
head(select(IRIS_TABLE, Sepal.Length, species = Species))

# filter data by specified condition
filter(IRIS_TABLE, Sepal.Length > 6.5 & Species == "versicolor")

# arrange data by specified columns
head(arrange(IRIS_TABLE, Sepal.Length, Sepal.Width))

# arrange data by specified columns in increasing order
head(arrange(IRIS_TABLE, desc(Sepal.Length), desc(Sepal.Width)))

# mutate data columna by specified expression
head(mutate(IRIS_TABLE, sepal = (Sepal.Length + Sepal.Width)/2))

##
## Grouping
##

# group data by specified column
IRIS_TABLE_G <- group_by(IRIS_TABLE, Species)

# group column name
groups(IRIS_TABLE_G)

# number of rows in each group
group_size(IRIS_TABLE_G)

##
## Aggregation
##

# summarise data by specified aggregate function
summarise(IRIS_TABLE, m = mean(Sepal.Length), sd = sd(Sepal.Width))

# summarise data over group
arrange(summarise(IRIS_TABLE_G, m = mean(Sepal.Length), sd = sd(Sepal.Width)), Species)

# tally data by number of rows
tally(IRIS_TABLE)

# tally data by specified weight column
tally(IRIS_TABLE, wt = Sepal.Length)

# tally data over group
tally(IRIS_TABLE_G, wt = Sepal.Length, sort = TRUE)

##
## Sampling
##

set.seed(123)

# sample data by specified number of rows
sample_n(IRIS_TABLE, 15L)

# sample data by specified percentage
sample_frac(IRIS_TABLE, 0.1)

# sample data over group
sample_n(IRIS_TABLE_G, 5L)
sample_frac(IRIS_TABLE_G, 0.1)

##
## Ranking
##

# first, last, nth
filter(IRIS_TABLE, Sepal.Width == first(Sepal.Width))
filter(IRIS_TABLE, Sepal.Width == last(Sepal.Width))
filter(IRIS_TABLE, Sepal.Width == nth(Sepal.Width, 5L))

# top n rows by specified weight column
top_n(IRIS_TABLE, n = 10L, wt = Sepal.Length)

# rank on specified column
head(transmute(IRIS_TABLE, Sepal.Width, min.rank = min_rank(Sepal.Width),
               dense.rank = dense_rank(Sepal.Width)), 10L)

# rank on specified column over group
top_n(IRIS_TABLE_G, n = 5L, wt = Sepal.Length)

transmute(IRIS_TABLE_G, Sepal.Width, min.rank = min_rank(Sepal.Width),
          dense.rank = dense_rank(Sepal.Width))

# End of ore_dplyr.R
