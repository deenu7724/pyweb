#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_ralg.R
#     Description: ORE Interface to Oracle Data Mining Extensible R
#                  Algorithm
#

IRIS <- ore.push(iris)

ore.scriptCreate("glm_build", function(data, form, family)
    glm(formula = form, data = data, family = family))

ore.scriptCreate("glm_score", function(mod, data) {
    res <- predict(mod, newdata = data); data.frame(res)})

ore.scriptCreate("glm_detail", function(mod)
    data.frame(name=names(mod$coefficients), coef=mod$coefficients))

ore.scriptList(name = "glm_build")
ore.scriptList(name = "glm_score")
ore.scriptList(name = "glm_detail")

ralg.mod <- ore.odmRAlg(IRIS, mining.function = "regression",
  formula = c(form="Sepal.Length ~ ."),
  build.function = "glm_build", build.parameter = list(family="gaussian"),
  score.function = "glm_score",
  detail.function = "glm_detail", detail.value = data.frame(name="a", coef=1))

summary(ralg.mod)
ralg.mod$details

predict(ralg.mod, newdata = head(IRIS), supplemental.cols = "Sepal.Length")

ore.scriptDrop(name = "glm_build")
ore.scriptDrop(name = "glm_score")
ore.scriptDrop(name = "glm_detail")

