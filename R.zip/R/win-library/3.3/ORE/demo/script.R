#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: script.R
#     Description: Create, list, load, drop, grant, and revoke R script
#
#

## Set page width
options(width = 80)

# Create an R script for the current user
ore.scriptCreate("MYLM",
                 function(data, formula, ...) lm(formula, data, ...))
IRIS <- ore.push(iris)
ore.tableApply(IRIS[1:5], FUN.NAME = "MYLM", formula = Sepal.Length ~ .)

# Create a global R script available to any user
ore.scriptCreate("GLBGLM", function(data, formula, ...) 
                                    glm(formula=formula, data=data, ...),
                 global = TRUE)
ore.tableApply(IRIS[1:5], FUN.NAME = "GLBGLM",
               formula = Sepal.Length ~ .) 

# List R scripts 
ore.scriptList()
ore.scriptList(pattern="LM", type="all")

# Load an R script into an R function
ore.scriptLoad(name="MYLM")
ore.scriptLoad(name="GLBGLM", newname="MYGLM")
MYLM(iris, formula = Sepal.Length ~ .)
MYGLM(iris, formula = Sepal.Length ~ .)

# Grant and revoke R script read privilege to and from public
ore.grant(name="MYLM", type="rqscript")
ore.scriptList(type="grant")
ore.revoke(name="MYLM", type="rqscript")
ore.scriptList(type="grant")  

# Drop an R script
ore.scriptDrop("MYLM")
ore.scriptDrop("GLBGLM", global=TRUE)

ore.scriptList(type="all")
