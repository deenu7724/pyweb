#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: binning.R
#     Description: Demonstrates binning logic in R
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Create bins based on Petal Length
iris$PetalBins = ifelse(iris$Petal.Length < 2.0, "SMALL PETALS",
                 ifelse(iris$Petal.Length < 4.0, "MEDIUM PETALS",
                 ifelse(iris$Petal.Length < 6.0, "MEDIUM LARGE PETALS",
                        "LARGE PETALS")))

# Look at the BINS now
iris

# Repeat on ore.frame
IRIS_TABLE$PetalBins = ifelse(IRIS_TABLE$Petal.Length < 2.0, "SMALL PETALS",
                       ifelse(IRIS_TABLE$Petal.Length < 4.0, "MEDIUM PETALS",
                       ifelse(IRIS_TABLE$Petal.Length < 6.0,
                              "MEDIUM LARGE PETALS", "LARGE PETALS")))

IRIS_TABLE

# Reusable binning logic - a.l.a FORMATs in SAS
PetalBins = function(x)
{
    ifelse(x < 2.0, "SMALL PETALS",
    ifelse(x < 4.0, "MEDIUM PETALS",
    ifelse(x < 6.0, "MEDIUM LARGE PETALS", "LARGE PETALS")))
}

PetalBins(IRIS_TABLE$Petal.Length)
PetalBins(iris$Petal.Length)
