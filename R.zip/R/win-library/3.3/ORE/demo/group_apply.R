#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: group_apply.R
#     Description: Execute R code for different sets of rows one set
#                  per group
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Repeat for each unique value of SPECIES
res = ore.groupApply(IRIS_TABLE,
                     IRIS_TABLE$Species,
                     function(dat)
                     {
                         # Any R code goes here.
                         # Reference group id by indexing into SPECIES as
                         # shown below
                         data.frame(SP = dat$Species[1], CNT = nrow(dat))
                     })
res

# Build one regression model per species
mod = ore.groupApply(IRIS_TABLE[, c("Petal.Length", "Petal.Width", "Species")],
                     IRIS_TABLE$Species,
                     function(dat)
                     {
                         lm(Petal.Length ~ Petal.Width, dat)
                     })
mod
