#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: randomForest.R
#     Description: randomForest
#
#
#

## Set page width
options(width = 80, warn= -1)

# infert dataset
INFERT <- ore.push(infert)

formula <- case ~ age + parity + education + spontaneous + induced

rfMod <- ore.randomForest(formula, INFERT, ntree=1000, nodesize = 2)

tree <- grabTree(rfMod, k = 500)

rfPred <- predict(rfMod, INFERT, supplemental.cols = "case")

confusion.matrix <- with(rfPred, table(case, prediction))

# mtcars dataset
m <- mtcars
m$cyl <- as.factor(m$cyl)
m$vs <- as.factor(m$vs)
MTCARS <- ore.push(m)

formula <- gear~.

rfMod <- ore.randomForest(formula, MTCARS)

tree <- grabTree(rfMod, k = 10, labelVar = TRUE)

rfPred <- predict(rfMod, MTCARS, type = "all", supplemental.cols="gear")

confusion.matrix <- with(rfPred, table(gear, prediction))

# End of randomForest.R
