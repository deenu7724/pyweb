#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: derived.R
#     Description: Handling of derived columns
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Lets register the set of columns we begin with
names(IRIS_TABLE)

# Add one column derived from another
IRIS_TABLE = transform(IRIS_TABLE, LOG_PL = log(Petal.Length))

# Alternatively..
IRIS_TABLE$LOG_PL1 = log(IRIS_TABLE$Petal.Length)

# Notice both columns have gotten added
names(IRIS_TABLE)

# Verify the 2 added columns have the same value
head(IRIS_TABLE)

# If you want to go back to the basic IRIS_TABLE with NO extra columns
IRIS_TABLE <- subset(IRIS_TABLE, select = -c(LOG_PL))
IRIS_TABLE <- subset(IRIS_TABLE, select = -c(LOG_PL1))
names(IRIS_TABLE)
class(IRIS_TABLE)
head(IRIS_TABLE)

# Add many more columns
IRIS_TABLE = transform(IRIS_TABLE,
                       SEPALBINS = ifelse(Sepal.Length < 3.0, "A", "B"),
                       PRODUCTCOLUMN = Petal.Length * Petal.Width,
                       CONSTANTCOLUMN = 10)

head(IRIS_TABLE)

# IRIS_TABLE is now a view
# If you want to create a physical table out of it ....
ore.create(IRIS_TABLE, table = "NEW_IRIS_TABLE")

# sync newly created table
ore.sync(table="NEW_IRIS_TABLE")

# Notice the new table appear in the environment
ore.ls()

# Drop the table
ore.drop(table = "NEW_IRIS_TABLE")

# Table is gone
ore.ls()
