#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_nmf.R
#     Description: ORE Interface to Oracle Data Mining Non-Negative Matrix
#                  Factorization
#

training.set <- ore.push(npk[1:18, c("N","P","K")])
scoring.set <- ore.push(npk[19:24, c("N","P","K")])

nmf.mod <- ore.odmNMF(~., training.set, num.features = 3)

summary(nmf.mod)
features(nmf.mod)

predict(nmf.mod, scoring.set)
predict(nmf.mod, scoring.set, supplemental.cols=c("N", "P", "K"))
predict(nmf.mod, scoring.set, type = "class", supplemental.cols=c("N", "P", "K"))
