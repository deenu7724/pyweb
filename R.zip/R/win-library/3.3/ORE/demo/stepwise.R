#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: stepwise.R
#     Description: STEPWISE Multivariate Regression
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE
class(IRIS_TABLE)

# Let us first project out the non numeric columns
IRIS_TABLE = IRIS_TABLE[, c("Sepal.Length", "Sepal.Width",
                            "Petal.Length", "Petal.Width")]

# Predict Sepal.Length based on the other 3 numeric columns
# Do it stepwise
model = ore.lm(Sepal.Length ~ ., data = IRIS_TABLE)
model
summary(model)
confint(model)

# Backward selection
step(model, direction = "backward")

# Forward selection
step(ore.lm(Sepal.Length ~ 1, data = IRIS_TABLE),
     terms(Sepal.Length ~ ., data = IRIS_TABLE),
     direction = "forward")

# Stepwise selection
step(ore.lm(Sepal.Length ~ 1, data = IRIS_TABLE),
     list(lower = Sepal.Length ~ 1,
          upper = terms(Sepal.Length ~ ., data = IRIS_TABLE)))
