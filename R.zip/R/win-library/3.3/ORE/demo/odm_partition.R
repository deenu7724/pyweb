#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_partition.R
#     Description: ORE Interface to Oracle Data Mining Partition Model
#

##
## Synthetic data set
##

set.seed(7654)
x <- seq(0.1, 5, by = 0.02)
y <- log(x) + rnorm(x, sd = 0.2)

## ore.odmSVM
dat <-ore.push(data.frame(X=x, Y=y, part=seq(length(x))%%2L))
svm.pmod <- NULL
svm.pmod <- ore.odmSVM(Y~X, dat, "regression",kernel.function = "linear",
                       auto.data.prep = FALSE,
                       odm.settings = list(odms_partition_columns = "part"))
settings(svm.pmod)
partitions(svm.pmod)
summary(svm.pmod)
head(predict(svm.pmod,dat,supplemental.cols=c("X","Y")))

# End of odm_partition.R
