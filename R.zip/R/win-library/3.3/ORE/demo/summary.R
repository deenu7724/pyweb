#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: summary.R
#     Description: Demonstrates summary functionality
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Basic R summary functionality
summary(iris)
summary(IRIS_TABLE)

# More sophisticated summarizations available only for ore.frames
# Default aggregation functions : count, min, max and mean
# Other aggregation functions supported:
#  nmiss,css,uss,cv,sum,sumwgt,range,stddev,stderr,var,t,kurt,skew,
#  p1,p5,p10,p25,p50,p75,p90,p95,p99,qrange, mode
#
# Get default summaries for Petal.Length, rollup(Species)
x = ore.summary(IRIS_TABLE, class = "Species", var = "Petal.Length",
                order = "-class")
class(x)
x

# Rollup(more than 1 column)
# Generate summary for more than 1 variable
x = ore.summary(IRIS_TABLE, var = c("Petal.Length", "Sepal.Length"),
  class = c("Species", "Petal.Width"), order = "class")
x

# Get just the stats you need.
# Just get max and min values of different columns
x = ore.summary(IRIS_TABLE, var = list("Petal.Length", "Sepal.Length"),
  class = c("Species", "Petal.Width"),
  stats = c("max", "min"), order = c("type", "class"))
x

# Restrict output to certain group-bys from the ROLLUP
# using types or ways or both
x = ore.summary(IRIS_TABLE, var = "Petal.Length",
  class = c("Species", "Petal.Width"), stats = "min",
  types = list("Species", c("Species", "Petal.Width")),
  order = c("type", "class"))
x

x = ore.summary(IRIS_TABLE, var = "Petal.Length",
  class = c("Species", "Petal.Width"), stats = "min",
  ways = 2,
  order = c("type", "class"))
x

x = ore.summary(IRIS_TABLE, var = "Petal.Length",
  class = c("Species", "Petal.Width"), stats = "min",
  types = list("Species"), ways = 2,
  order = c("type", "class"))
x

# Use a column as weight for statistices
x = ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            weight = "Sepal.Width", order = "-class")
x

# Sort output by various criteria
#
# Sort by freq column
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            order = "freq")
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            order = "-freq")

# Sort by type column
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            order = "type")
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            order = "-type")

# Sort by grouping column
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            order = "class")
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            order = "-class")

# For each aggregate, print Petal.Length of that observation that has
# the maximum value for Petal.Width
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            maxid = c(Petal.Width = "Petal.Length"),
            order = "-class")

# For each aggregate, print Petal.Length of that observation that has
# the minimum value for Petal.Width
ore.summary(IRIS_TABLE, var = "Petal.Length", class = "Species", 
            minid = c(Petal.Width = "Petal.Length"),
            order = "-class")
