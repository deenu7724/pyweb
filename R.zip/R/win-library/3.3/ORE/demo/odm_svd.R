#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_svd.R
#     Description: ORE Interface to Oracle Data Mining Singular Value
#                  Decomposition
#

options(digits = 3L)

hilbert <- function(n) { i <- 1:n; 1 / outer(i - 1, i, "+") }
X <- ore.push(as.data.frame(hilbert(9)[, 1:6]))

svd.mod <- ore.odmSVD(~., X)
summary(svd.mod)
features(svd.mod)

d(svd.mod)
v(svd.mod)

print(predict(svd.mod, X), digits = 2L)
