#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_nb.R
#     Description: ORE Interface to Oracle Data Mining Naive Bayes
#

##
## R iris data set
##

IRIS <- ore.push(iris)

nb.mod <- NULL
nb.res <- NULL
nb.mod  <- ore.odmNB(Species ~ ., IRIS)
summary(nb.mod)
nb.res  <- predict (nb.mod, IRIS,"Species")
with(nb.res, table(Species,PREDICTION))  # generate confusion matrix

##  
## MTCARS sample data set
##

m <- mtcars
m$gear <- as.factor(m$gear)
m$cyl  <- as.factor(m$cyl)
m$vs   <- as.factor(m$vs)
m$ID   <- 1:nrow(m)
MTCARS <- ore.push(m)
row.names(MTCARS) <- MTCARS$ID

nb.mod  <- NULL
nb.mod  <- ore.odmNB(gear ~ ., MTCARS)
summary(nb.mod)

nb.res  <- predict (nb.mod, MTCARS,"gear")
with(nb.res, table(gear,PREDICTION))  # generate confusion matrix


# End of odm_nb.R
