#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_kmeans.R
#     Description: ORE Interface to Oracle Data Mining K-Means
#

##
## Synthetic 2-dimensional data set
##

set.seed(7654)

x <- rbind(matrix(rnorm(100, sd = 0.3), ncol = 2),
           matrix(rnorm(100, mean = 1, sd = 0.3), ncol = 2))
colnames(x) <- c("x", "y")

X <- ore.push (data.frame(x))
km.mod1 <- NULL
km.mod1 <- ore.odmKMeans(~., X, num.centers=2)
km.mod1
summary(km.mod1)
rules(km.mod1)
clusterhists(km.mod1)
histogram(km.mod1)

km.res1 <- predict(km.mod1,X,type="class",supplemental.cols=c("x","y"))
head(km.res1,3)
km.res1.local <- ore.pull(km.res1)
plot(data.frame(x=km.res1.local$x, y=km.res1.local$y), col=km.res1.local$CLUSTER_ID)
points(km.mod1$centers2, col = rownames(km.mod1$centers2), pch = 8, cex=2)

head(predict(km.mod1,X))
head(predict(km.mod1,X,type=c("class","raw")),3)
head(predict(km.mod1,X,type=c("class","raw"),supplemental.cols=c("x","y")),3)
head(predict(km.mod1,X,type="raw",supplemental.cols=c("x","y")),3)

##
## Synthetic 3-dimensional data set
##

set.seed(7654)

x <- rbind(matrix(rnorm(300, sd = 0.3), ncol = 3),
           matrix(rnorm(300, mean = 1, sd = 0.3), ncol = 3),
           matrix(rnorm(300, mean = 2, sd = 0.5), ncol = 3))
colnames(x) <- c("x", "y","z")
X <- ore.push (data.frame(x))
km.mod1 <- NULL
km.mod1 <- ore.odmKMeans(~., X,num.centers=5)
histogram(km.mod1)
km.res1 <- predict(km.mod1,X,type="class",supplemental.cols=c("x","y","z"))
km.res1.local <- ore.pull(km.res1)
x2 <- km.mod1$centers2

# install scatterplot3d to enable the following

# library(scatterplot3d)
# s3d <- scatterplot3d(km.res1.local$x, km.res1.local$y, km.res1.local$z, color = km.res1.local$CLUSTER_ID)
# s3d$points3d(x2[,1], x2[,2], x2[,3], col = rownames(x2), pch = 8, cex=2)

##
## R mtcars data set
##

X <- ore.push (data.frame(name=rownames(mtcars),mtcars))
km.mod1 <- NULL
km.mod1 <- ore.odmKMeans(~.-name, X, num.centers=4)
summary(km.mod1)
histogram(km.mod1)

km.res1 <- ore.pull(predict(km.mod1,X,type="class", supplemental.cols="name"))
km.res1[order(km.res1$CLUSTER_ID),]


# End of odm_kmeans.R
