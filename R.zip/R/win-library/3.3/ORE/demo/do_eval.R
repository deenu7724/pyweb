#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: doEval.R
#     Description: Demonstrates support for database enabled parallel
#                  simulations
#
#
#

## Set page width
options(width = 80)

# Invoke given R code "num" times taking as input "scale"

res <- ore.doEval(function (num = 10, scale = 100)
                  {
                     ID <- seq(num)
                     # Any additional R code goes here
                     # Output goes below accumulated into a data frame
                     data.frame(ID = ID, RES = ID / scale)
                  },
                  FUN.VALUE = data.frame(ID = 1, RES = 1)
                 )
class(res)
res
