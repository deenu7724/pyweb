#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_ar.R
#     Description: ORE Interface to Oracle Data Mining Association Rules
#

##
## Transactional data set
##
id <- c(1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3)
item <- c("b", "d", "e", "a", "b", "c", "e", "b", "c", "d", "e")
data.ore <- ore.frame(ID = id, ITEM = item)

# Build model with specifications.
ar.mod <- NULL
ar.mod <- ore.odmAssocRules(~., data.ore, case.id.column = "ID",
item.id.column = "ITEM", min.support = 0.6, min.confidence = 0.6,
max.rule.length = 3)

# Generate itemsets and rules of the model.
itemsets <- itemsets(ar.mod)
rules <- rules(ar.mod)

# subsetting
sub.itemsets <- subset(itemsets, min.support=0.7, items=list("b"))
sub.itemsets
sub.rules <- subset(rules, min.confidence=0.7, lhs=list("d"), rhs=list("b"))
sub.rules

##
## Multi-record case data
##
id <- c(1, 1, 2, 2, 3, 3, 3, 4, 4, 5, 5, 6, 6, 7, 8, 8, 9, 9, 10, 11, 12, 12, 13, 14, 15, 16, 17)
item <- c("a","b","a","b","a","c","d","c","d","c","d","c","d","d","d","a","d","e","a","a","d","e","d","e","d","d","d")
value <- c(1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 3, 2, 1, 2, 3, 1, 2, 2, 3, 2, 3, 2, 3, 3)
data2.ore <- ore.frame(ID = id, ITEM = item, VALUE = value)

ar.mod <- NULL
ar.mod <- ore.odmAssocRules(~., data2.ore, case.id.column = "ID",
item.id.column = "ITEM", item.value.column = "VALUE", max.rule.length = 3,
                            min.support = 0.05, min.confidence = 0.05)

summary(ar.mod)

subset(rules(ar.mod), min.rule.length=3)
subset(itemsets(ar.mod), max.itemset.length=2)

##
## Relational data in a single-record case table
##
set.seed(7654)
id <- 1:10
color <- sample(c("B", "Y", "W", "G"), 10, replace=TRUE)
shape <- sample(c("tri", "rect", "round"), 10, replace=TRUE)
state <- sample(c("MA", "CA", "NY"), 10, replace=TRUE)
data3.ore <- ore.frame(ID=id, COLOR=color, SHAPE=shape, STATE=state)

ar.mod <- NULL
ar.mod <- ore.odmAssocRules(~., data3.ore, case.id.column = "ID", min.support = 0.15,
                            min.confidence = 0.05, max.rule.length = 2)

subset(rules(ar.mod), min.confidence=0.5, lhs=list(SHAPE="tri", COLOR="B"),
       orderby="lift")
subset(itemsets(ar.mod), min.support=0.35)
