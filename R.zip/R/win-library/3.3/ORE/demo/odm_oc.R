#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_oc.R
#     Description: ORE Interface to Oracle Data Mining O-Cluster
#

##
## Synthetic 2-dimensional data set
##

set.seed(7654)

x <- rbind(matrix(rnorm(100, mean = 4, sd = 0.3), ncol = 2),
             matrix(rnorm(100, mean = 2, sd = 0.3), ncol = 2))
colnames(x) <- c("x", "y")

X <- ore.push (data.frame(ID=1:100,x))
rownames(X) <- X$ID

oc.mod <- NULL
oc.mod <- ore.odmOC(~., X, num.centers=2)

summary(oc.mod)
rules(oc.mod)
clusterhists(oc.mod)
histogram(oc.mod)

oc.res <- predict(oc.mod, X, type="class", supplemental.cols=c("x", "y"))
head(oc.res)
oc.res.local <- ore.pull(oc.res)
plot(data.frame(x=oc.res.local$x, y=oc.res.local$y), col=oc.res.local$CLUSTER_ID)
points(oc.mod$centers2, col = rownames(oc.mod$centers2), pch=8, cex=2)

head(predict(oc.mod,X))
head(predict(oc.mod,X,type=c("class","raw")))
head(predict(oc.mod,X,type=c("class","raw"),supplemental.cols=c("x","y")))
head(predict(oc.mod,X,type="raw",supplemental.cols=c("x","y")))
