#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: odm_glm.R
#     Description: ORE Interface to Oracle Data Mining GLM
#

# Linear regression using the longley data set
LONGLEY <- ore.push(longley)
longfit1 <- ore.odmGLM(Employed ~ ., data = LONGLEY)
summary(longfit1)

# Ridge regression using the longley data set
longfit2 <- ore.odmGLM(Employed ~ ., data = LONGLEY, ridge = TRUE,
                       ridge.vif = TRUE)
summary(longfit2)

# Logistic regression using the infert data set
INFERT <- ore.push(infert)
infit1 <- ore.odmGLM(case ~ age+parity+education+spontaneous+induced,
                     data = INFERT, type = "logistic")
infit1

# Changing the reference value to 1
infit2 <- ore.odmGLM(case ~ age+parity+education+spontaneous+induced,
                     data = INFERT, type = "logistic", reference = 1)
infit2


# End of odm_glm.R
