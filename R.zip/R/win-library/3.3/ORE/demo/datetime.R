#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: datetime.R
#     Description: Date/Time operations
#
#
#

## Set page width
options(width = 80)

## Simulate data
set.seed(0)
N <- 500
mydata <- data.frame(datetime =
                     seq(as.POSIXct("2001/01/01"),
                         as.POSIXct("2001/12/31"),
                         length.out = N),
                     difftime = as.difftime(runif(N), units = "mins"),
                     x = rnorm(N))
mydata$y <- mydata$x + diffinv(rnorm(N-1))

MYDATA <- ore.push(mydata)
class(MYDATA)
class(MYDATA$datetime)

## Order statistic aggregates
mindt      <- min(MYDATA$datetime)
maxdt      <- max(MYDATA$datetime)
rangedt    <- range(MYDATA$datetime)
mediandt   <- median(MYDATA$datetime)
quantiledt <- quantile(MYDATA$datetime, probs = c(0, 0.05, 0.1))

## Arithmetic
day1Shift <- MYDATA$datetime + as.difftime(1, units = "days")
class(day1Shift)

lag1Diff <- diff(MYDATA$datetime)
class(lag1Diff)

## Comparison
isQ1 <- MYDATA$datetime < as.Date("2001/04/01")
class(isQ1)

isMarch <- isQ1 & MYDATA$datetime > as.Date("2001/03/01")
class(isMarch)

## Date/time accessors
year <- ore.year(MYDATA$datetime)
class(year)
unique(year)

month <- ore.month(MYDATA$datetime)
class(month)
range(month)

dayOfMonth <- ore.mday(MYDATA$datetime)
class(dayOfMonth)
range(dayOfMonth)

hour <- ore.hour(MYDATA$datetime)
class(hour)
range(hour)

minute <- ore.minute(MYDATA$datetime)
class(minute)
range(minute)

second <- ore.second(MYDATA$datetime)
class(second)
range(second)

## Coercsion
dateOnly <- as.ore.date(MYDATA$datetime)
class(dateOnly)
sort(unique(dateOnly))

nameOfDay <- as.ore.character(MYDATA$datetime, format = "DAY")
class(nameOfDay)
sort(unique(nameOfDay))

dayOfYear <- as.integer(as.character(MYDATA$datetime, format = "DDD"))
class(dayOfYear)
range(dayOfYear)

quarter <- as.integer(as.character(MYDATA$datetime, format = "Q"))
class(quarter)
sort(unique(quarter))
