#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: glm.R
#     Description: Generalized Linear Regression
#
#
#

## Set page width
options(width = 80)

## load MASS package to get dataset
suppressMessages(library(MASS))

## Logistic Regression Example

# Push built-in infert data.frame to the database
INFERT <- ore.push(infert)

# Fit a logistic regression model
infertGlm <- ore.glm(case ~ age + parity + education + spontaneous + induced,
                     data = infert, family = binomial())

# Summarize the model
summary(infertGlm)

# Create model predictions
INFERT1 <- ore.frame(INFERT,
                    predict(infertGlm, INFERT, type = "response",
                            se.fit = TRUE))
head(INFERT1, 10)

# Create model predictions with supplemental columns

INFERT2 <- predict(infertGlm, INFERT, type = "response", se.fit = TRUE, 
                                    supplemental.cols = "age")
head(INFERT2, 10)

INFERT3 <- predict(infertGlm, INFERT, type = "response", se.fit = FALSE, 
                                    supplemental.cols = c("education","age"))
head(INFERT3, 10)


## Poisson Regression Example

# Push built-in housing data.frame
HOUSING <- ore.push(housing)

# Fit a poisson regression model
housingGlm <- ore.glm(Freq ~ Infl*Type*Cont + Sat*(Infl+Type+Cont),
                      data = HOUSING, family = poisson())

# Summarize the model
summary(housingGlm)

# Create model predictions
HOUSING <- ore.frame(HOUSING,
                     predict(housingGlm, HOUSING, type = "response",
                             se.fit = TRUE))
head(HOUSING, 10)

# End of glm.R
