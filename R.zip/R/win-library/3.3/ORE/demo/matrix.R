#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: matrix.R
#     Description: Demonstrates matrix related operations
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Project out the non-numeric columns
iris_proj = iris[, c("Sepal.Length", "Sepal.Width",
                     "Petal.Length", "Petal.Width")]
IRIS_TABLE_PROJ = IRIS_TABLE[, c("Sepal.Length", "Sepal.Width",
                                 "Petal.Length", "Petal.Width")]

# Oracle R Enterprise contains matrix classes to be used for matrix operations
iris_matrix = as.matrix(iris_proj)
IRIS_TABLE_MATRIX = as.matrix(IRIS_TABLE_PROJ)

# Display the class for the matrix objects
class(iris_matrix)
class(IRIS_TABLE_MATRIX)

# Count the number of rows and columns in the matrices
dim(iris_matrix)
dim(IRIS_TABLE_MATRIX)

# Create linear regression coefficients, by hand, for Sepal.Length
# based on the other 3 numeric columns
XtX <- crossprod(iris_matrix)        # t(iris_matrix) %*% iris_matrix
class(XtX)
dim(XtX)
solve(XtX[-1, -1], XtX[-1, 1])

# Compare with coefficients create by lm
coef(lm(Sepal.Length ~ . - 1, data = iris_proj))

# Repeat on the ore matrix
XtX <- crossprod(IRIS_TABLE_MATRIX)  # t(IRIS_TABLE_MATRIX) %*% IRIS_TABLE_MATRIX
class(XtX)
dim(XtX)

# Since matrix is small, read into memory
XtX <- ore.pull(XtX)
class(XtX)
solve(XtX[-1, -1], XtX[-1, 1])

# Create covariance matrix, by hand
# First use the scale function to subtract out column means
iris_scaled_matrix = as.matrix(scale(iris_proj, center = TRUE, scale = FALSE))
IRIS_SCALED_MATRIX = as.matrix(scale(IRIS_TABLE_PROJ, center = TRUE,
                                     scale = FALSE))

# Create covariance matrix from in-memory data
crossprod(iris_scaled_matrix) / (nrow(iris_scaled_matrix) - 1)

# Compare with results from cov
cov(iris_proj)

# Create covariance matrix from DB-resident data
crossprod(IRIS_SCALED_MATRIX) / (nrow(IRIS_SCALED_MATRIX) - 1)

# Compare with results from cov
cov(IRIS_TABLE_PROJ)
