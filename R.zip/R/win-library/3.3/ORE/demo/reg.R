#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: reg.R
#     Description: Multivariate Regression
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Project out the non-numeric columns
iris_proj = iris[, c("Sepal.Length", "Sepal.Width",
                     "Petal.Length", "Petal.Width")]
IRIS_TABLE_PROJ = IRIS_TABLE[, c("Sepal.Length", "Sepal.Width",
                                 "Petal.Length", "Petal.Width")]

# Predict Sepal.Length based on the other 3 numeric columns
model = lm(Sepal.Length ~ ., data = iris_proj)
model
summary(model)
confint(model)

# Repeat on the ore data frame
model = ore.lm(Sepal.Length ~ ., data = IRIS_TABLE_PROJ)
model
summary(model)
confint(model)

# Apply the model to predict
predict(model, IRIS_TABLE_PROJ)
