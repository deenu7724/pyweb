#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: cor.R
#     Description: Correlation matrix
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Remove non numeric columns
iris_numeric = IRIS_TABLE[, c("Sepal.Length", "Sepal.Width",
                              "Petal.Length", "Petal.Width")]

# Pearson's correlation matrix
cor(iris_numeric, use = "all.obs")

# Spearman's rho/Kendall's tau

ore.corr(iris_numeric,
         c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width"),
         stats = "pearson")
ore.corr(iris_numeric,
         c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width"),
         stats = "spearman")
ore.corr(iris_numeric,
         c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width"),
         stats = "kendall")

#
# Morph output of ore.corr to match that of R's cor()
#
x = ore.corr(iris_numeric,
             c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width"),
             stats = "pearson")
y = OREeda:::.ore.corr.as.matrix(x)
y
