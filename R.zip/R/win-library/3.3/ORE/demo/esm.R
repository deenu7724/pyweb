#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: esm.R
#     Description: Exponential Smoothing Method
#


##
## Time series data set
##
set.seed(7654)
N <- 5000
ts0 <- ore.push(data.frame(ID=1:N, VAL=seq(1,5,length.out=N)^2+rnorm(N,sd=0.5)))
rownames(ts0) <- ts0$ID
x <- ts0$VAL

esm.mod <- NULL
esm.mod <- ore.esm(x, model = "double")
esm.mod
                
esm.predict <- predict(esm.mod, 30)
head(esm.predict)
esm.fitted <- fitted(esm.mod, start=4000, end=5000)
head(esm.fitted)
plot(ts0[4000:5000,], pch='.')
lines(ts0[4000:5000, 1], esm.fitted, col="blue")
lines(esm.predict, col="red", lwd=2)


##
## Transactional data set
##
ts01 <- data.frame(ID=seq(as.POSIXct("2008/6/13"), as.POSIXct("2011/6/16"),
                   length.out=4000), VAL=rnorm(4000, 10))
ts02 <- data.frame(ID=seq(as.POSIXct("2011/7/19"), as.POSIXct("2012/11/20"),
                   length.out=1500), VAL=rnorm(1500, 10))
ts03 <- data.frame(ID=seq(as.POSIXct("2012/12/09"), as.POSIXct("2013/9/25"),
                   length.out=1000), VAL=rnorm(1000, 10))
ts1 = ore.push(rbind(ts01, ts02, ts03))
rownames(ts1) <- ts1$ID
x <- ts1$VAL

esm.mod <- NULL
esm.mod <- ore.esm(x, "DAY", accumulate = "AVG", model="simple",
                   setmissing="PREV")
esm.mod

esm.predict <- predict(esm.mod)
esm.predict


##
## BJsales data set
##
x <- ore.push(BJsales)

esm.mod <- NULL
esm.mod <- ore.esm(x, model="double")
esm.mod

esm.predict <- predict(esm.mod)
esm.predict
esm.fitted <- fitted(esm.mod)
esm.fitted
plot(x)
lines(esm.fitted, col="blue")
lines(esm.predict, col="red", lwd=4)
