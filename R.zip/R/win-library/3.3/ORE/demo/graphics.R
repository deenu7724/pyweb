#
#     O R A C L E  R  E N T E R P R I S E  S A M P L E   L I B R A R Y
#
#     Name: graphics.R
#     Description: Demonstrates visual analysis
#
#
#

## Set page width
options(width = 80)

# Push the built-in iris data frame to the database
IRIS_TABLE <- ore.push(iris)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# See below for various types of graphics on table objects
pairs(IRIS_TABLE)
boxplot(IRIS_TABLE$Petal.Length)
hist(IRIS_TABLE$Petal.Length)

plot(log(Sepal.Length) ~ log(Petal.Length), data = IRIS_TABLE)
points(log(Sepal.Length) ~ log(Petal.Length), data = IRIS_TABLE,
       pch = 2, col="red")
lines(log(Sepal.Length) ~ log(Petal.Length), data = IRIS_TABLE,
      col = "blue")

plot(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length), type = "n")
polygon(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length),
        col = "blue")

plot(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length), type = "n")
polypath(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length))

plot(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length))
xspline(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length), 1,
        border = "red")
rug(log(IRIS_TABLE$Sepal.Length), col = "blue")

plot(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length))
segments(log(IRIS_TABLE$Sepal.Length), log(IRIS_TABLE$Petal.Length),
         IRIS_TABLE$Petal.Width + IRIS_TABLE$Sepal.Width, col = "blue")

smoothScatter(IRIS_TABLE$Petal.Length, IRIS_TABLE$Sepal.Length)

sunflowerplot(IRIS_TABLE$Petal.Length, IRIS_TABLE$Sepal.Length)

matplot(IRIS_TABLE, type = "n")
matpoints(IRIS_TABLE)
matlines(IRIS_TABLE)
