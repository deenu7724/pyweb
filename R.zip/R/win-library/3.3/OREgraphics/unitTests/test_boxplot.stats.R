test_ore.vector_boxplot.stats <- function()
{
    compareBPStats <- function(x, y)
    {
        x[["out"]] <- sort(x[["out"]])
        y[["out"]] <- sort(x[["out"]])
        checkEquals(x, y, tolerance = 5e-6)
    }

    checkException(boxplot.stats(NARROW[["AGE"]], coef = -1), silent = TRUE)

    for (coef in c(0, 1, 1.5))
        for (do.conf in c(TRUE, FALSE))
            for (do.out in c(TRUE, FALSE))
                for (j in c("ID", "AGE", "YRS_RESIDENCE"))
                    compareBPStats(boxplot.stats(NARROW[[j]], coef = coef,
                                                 do.conf = do.conf,
                                                 do.out = do.out),
                                   boxplot.stats(ore.pull(NARROW[[j]]),
                                                 coef = coef,
                                                 do.conf = do.conf,
                                                 do.out = do.out))
}

