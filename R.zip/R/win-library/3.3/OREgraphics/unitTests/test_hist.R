test_ore.vector_hist <- function()
{
    compareHistStats <- function(x, y)
    {
        x[["xname"]] <- y[["xname"]]
        checkEquals(x, y)
    }

    for (j in c("ID", "AGE", "YRS_RESIDENCE"))
        compareHistStats(hist(NARROW[[j]], plot = FALSE),
                         hist(ore.pull(NARROW[[j]]), right = FALSE,
                              plot = FALSE))
}

